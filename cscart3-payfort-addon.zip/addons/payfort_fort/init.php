<?php
if ( !defined('AREA') ) { die('Access denied'); }

fn_register_hooks(
//      'pre_place_order'
);

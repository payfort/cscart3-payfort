<?php
if ( !defined('AREA') ) { die('Access denied'); }

//
// Defined variables
//